package com.app.savecity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SavecityApplicationTests {

	@Test
	void contextLoads() {
	}

}
