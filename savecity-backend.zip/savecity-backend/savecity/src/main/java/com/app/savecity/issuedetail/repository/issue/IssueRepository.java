package com.app.savecity.issuedetail.repository.issue;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.savecity.issuedetail.entites.issues.Issue;

public interface IssueRepository  extends JpaRepository<Issue,Long> {

}
