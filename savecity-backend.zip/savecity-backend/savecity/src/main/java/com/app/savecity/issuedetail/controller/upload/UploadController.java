
package com.app.savecity.issuedetail.controller.upload;

import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.app.savecity.issuedetail.entites.issues.Upload;
import com.app.savecity.issuedetail.service.upload.UploadService;

@RestController
public class UploadController {

    @Autowired
    private UploadService uploadService;

    @PostMapping("/upload/image")
    public ResponseEntity<String> uploadImage(@RequestParam("file") MultipartFile file) {
        try {
            Upload upload = uploadService.saveImage(file);
            return ResponseEntity.ok("Image uploaded successfully with ID: " + upload.getFileId());
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Upload failed!");
        }
    }

    @GetMapping("/upload/image/{id}")
    public ResponseEntity<byte[]> getImage(@PathVariable Long id) {
        Optional<Upload> upload = uploadService.getImageById(id);
        if (upload.isPresent()) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.valueOf(upload.get().getFileType()));
            return new ResponseEntity<>(upload.get().getFile(), headers, HttpStatus.OK);
        }
        return ResponseEntity.notFound().build();
    }
}
