
package com.app.savecity.issuedetail.entites.issues;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Issue {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String description;
    private String location;
    private String issueType;
    private String uploadIds;

    public Issue() {
    }

    public Issue(Long id, String description, String location, String issueType, String uploadIds) {
        this.id = id;
        this.description = description;
        this.location = location;
        this.issueType = issueType;
        this.uploadIds = uploadIds;
    }

    @Override
	public String toString() {
		return "Issue [id=" + id + ", description=" + description + ", location=" + location + ", issueType="
				+ issueType + ", uploadIds=" + uploadIds + "]";
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getIssueType() {
        return issueType;
    }

    public void setIssueType(String issueType) {
        this.issueType = issueType;
    }

    public String getUploadIds() {
        return uploadIds;
    }

    public void setUploadIds(String uploadIds) {
        this.uploadIds = uploadIds;
    }
    
}
