package com.app.savecity.issuedetail.repository.image;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.savecity.issuedetail.entites.issues.Upload;

public interface ImageRepository extends JpaRepository<Upload,Long> {

}
