
package com.app.savecity.issuedetail.controller.issue;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.app.savecity.issuedetail.entites.issues.Issue;
import com.app.savecity.issuedetail.service.issue.IssueService;

@RestController
public class IssueController {

    @Autowired
    private IssueService issueService;

    @PostMapping("/issue/create")
    public ResponseEntity<Issue> createIssue(
            @RequestParam String description,
            @RequestParam(required = false) List<MultipartFile> files,
            @RequestParam String location,
            @RequestParam String issueType) {
        Issue issue = issueService.createIssue(description, files, location, issueType);
        return ResponseEntity.ok(issue);
    }

    @GetMapping("/issue/{id}")
    public ResponseEntity<Issue> getIssueById(@PathVariable Long id) {
        return issueService.getIssueById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/issue/issues")
    public ResponseEntity<List<Issue>> getAllIssues() {
        return ResponseEntity.ok(issueService.getAllIssues());
    }

    @DeleteMapping("/issue/{id}")
    public ResponseEntity<Void> deleteIssue(@PathVariable Long id) {
        return issueService.deleteIssue(id) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}
