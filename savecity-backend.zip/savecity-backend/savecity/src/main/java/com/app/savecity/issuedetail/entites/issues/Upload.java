
package com.app.savecity.issuedetail.entites.issues;

import java.util.Arrays;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;

@Entity
public class Upload {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long fileId;

    @Lob
    private byte[] file;

    private String fileName;
    private String fileType;

    public Upload() {
    }

    public Upload(Long fileId, byte[] file, String fileName, String fileType) {
        this.fileId = fileId;
        this.file = file;
        this.fileName = fileName;
        this.fileType = fileType;
    }

    public Long getFileId() {
        return fileId;
    }

    public void setFileId(Long fileId) {
        this.fileId = fileId;
    }

    public byte[] getFile() {
        return file;
    }

    public void setFile(byte[] file) {
        this.file = file;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

	@Override
	public String toString() {
		return "Upload [fileId=" + fileId + ", file=" + Arrays.toString(file) + ", fileName=" + fileName + ", fileType="
				+ fileType + "]";
	}
}
