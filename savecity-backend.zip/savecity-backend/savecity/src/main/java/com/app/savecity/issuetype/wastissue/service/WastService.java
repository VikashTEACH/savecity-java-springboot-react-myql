package com.app.savecity.issuetype.wastissue.service;

import java.util.List;

import com.app.savecity.exception.error.EntityNotFoundException;
import com.app.savecity.issuetype.wastissue.entity.WastEntity;


public interface WastService {

	List<WastEntity> findAllWastIssue() throws EntityNotFoundException;

	WastEntity findWastIssueById(Long id) throws EntityNotFoundException;

	WastEntity updateWastIssue(WastEntity wastEntity, Long id);

	WastEntity saveWastIssue(WastEntity wastEntity);

}
