


package com.app.savecity.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.app.savecity.userdetail.user.UserCredentialEntity;
import com.app.savecity.userdetail.user.UserCredentialEntity.Role;
import com.app.savecity.userdetail.userrepository.UserCredentialRepository;

import java.util.Map;

@Service
public class CredentialService {

    @Autowired
    private UserCredentialRepository repo;

    @Autowired
    private PasswordEncoder encoder;

    public String registerUserWithRole(
            String username, String password, String email, Role role) {
        if (repo.findByEmail(email).isPresent())
            throw new IllegalArgumentException("User with this email already exists.");
        if (repo.findByUsername(username).isPresent())
            throw new IllegalArgumentException("Username already taken.");

        UserCredentialEntity u = new UserCredentialEntity();
        u.setUsername(username);
        u.setEmail(email);
        u.setPassword(encoder.encode(password));
        u.setRole(role);
        repo.save(u);

        return switch (role) {
            case ROLE_ADMIN   -> "Admin registered successfully";
            case ROLE_OFFICER -> "Officer registered successfully";
            default           -> "User registered successfully";
        };
    }

    public String registerUser(Map<String,String> req) {
        return registerUserWithRole(
            req.get("username"), req.get("password"), req.get("email"), Role.ROLE_USER);
    }

    public String registerAdmin(String u, String p, String e) {
        return registerUserWithRole(u, p, e, Role.ROLE_ADMIN);
    }

    public String registerOfficer(String u, String p, String e) {
        return registerUserWithRole(u, p, e, Role.ROLE_OFFICER);
    }

    public UserCredentialEntity validateUser(String email, String password) {
        UserCredentialEntity user = repo.findByEmail(email)
            .orElseThrow(() -> new IllegalArgumentException("Invalid email or password"));
        if (!encoder.matches(password, user.getPassword()))
            throw new IllegalArgumentException("Invalid email or password");
        return user;
    }
}
