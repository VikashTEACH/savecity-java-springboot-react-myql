package com.app.savecity.security;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import com.app.savecity.userdetail.user.UserCredentialEntity;
import com.app.savecity.userdetail.userrepository.UserCredentialRepository;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UserCredentialRepository repo;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        UserCredentialEntity u = repo.findByEmail(email)
            .orElseThrow(() -> new UsernameNotFoundException("No user: " + email));
        return User.builder()
                   .username(u.getEmail())
                   .password(u.getPassword())
                   .authorities(u.getRole().name())
                   .build();
    }
}
