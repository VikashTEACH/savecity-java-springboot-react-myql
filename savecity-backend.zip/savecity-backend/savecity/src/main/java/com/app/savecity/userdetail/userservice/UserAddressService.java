package com.app.savecity.userdetail.userservice;


import com.app.savecity.userdetail.address.Address;


public interface UserAddressService {

	Address saveUserAddress( Address address);

}
