// package com.app.savecity.security;

// import io.jsonwebtoken.*;
// import org.springframework.stereotype.Component;

// import com.app.savecity.userdetail.user.UserCredentialEntity;

// import java.util.Date;

// @Component
// public class JwtUtil {

//     // Example of a generated secret key (you can replace this with your own secret key or generated key)
//     private String secretKey = "gYPy3B9w8F/FLT35lgWKbNzDGk6wQVOgGz6oDvF9t3g";  // Replace this with your generated key

//     // Generate JWT Token
//     public String generateToken(String email, UserCredentialEntity.Role role) {
//         return Jwts.builder()
//                 .setSubject(email)
//                 .claim("role", role.name())
//                 .setIssuedAt(new Date())
//                 .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 10))  // 10 hours
//                 .signWith(SignatureAlgorithm.HS256, secretKey)
//                 .compact();
//     }

//     // Validate JWT Token
//     public Claims extractClaims(String token) {
//         return Jwts.parser()
//                 .setSigningKey(secretKey)
//                 .parseClaimsJws(token)
//                 .getBody();
//     }

//     public String extractUsername(String token) {
//         return extractClaims(token).getSubject();
//     }

//     public boolean isTokenExpired(String token) {
//         return extractClaims(token).getExpiration().before(new Date());
//     }

//     public boolean validateToken(String token, String username) {
//         return (username.equals(extractUsername(token)) && !isTokenExpired(token));
//     }
// }



package com.app.savecity.security;

import io.jsonwebtoken.*;
import org.springframework.stereotype.Component;

import com.app.savecity.userdetail.user.UserCredentialEntity;

import java.util.Date;

@Component
public class JwtUtil {

    private String secretKey = "gYPy3B9w8F/FLT35lgWKbNzDGk6wQVOgGz6oDvF9t3g";  // Replace this with your generated key

    public String generateToken(String email, UserCredentialEntity.Role role) {
        return Jwts.builder()
                .setSubject(email)
                .claim("role", role.name())
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 10))  // 10 hours
                .signWith(SignatureAlgorithm.HS256, secretKey)
                .compact();
    }
    

    // Validate and Extract Claims from JWT Token
    public Claims extractClaims(String token) throws MalformedJwtException {
        try {
            return Jwts.parserBuilder()
                    .setSigningKey(secretKey)
                    .build()
                    .parseClaimsJws(token)
                    .getBody();
        } catch (JwtException | IllegalArgumentException e) {
            throw new MalformedJwtException("Invalid JWT token: " + e.getMessage(), e);
        }
    }

    // Extract the Username (Subject) from the Token
    public String extractUsername(String token) {
        return extractClaims(token).getSubject();
    }

    // Check if the Token is Expired
    public boolean isTokenExpired(String token) {
        return extractClaims(token).getExpiration().before(new Date());
    }

    // Validate the Token (checks username and expiration)
    public boolean validateToken(String token, String username) {
        return (username.equals(extractUsername(token)) && !isTokenExpired(token));
    }
}
