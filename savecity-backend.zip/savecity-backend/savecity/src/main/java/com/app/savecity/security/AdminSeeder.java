// package com.app.savecity.security;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.CommandLineRunner;
// import org.springframework.security.crypto.password.PasswordEncoder;
// import org.springframework.stereotype.Component;

// import com.app.savecity.userdetail.user.UserCredentialEntity;
// import com.app.savecity.userdetail.user.UserCredentialEntity.Role;
// import com.app.savecity.userdetail.userrepository.UserCredentialRepository;

// @Component
// public class AdminSeeder implements CommandLineRunner {

//     @Autowired
//     private UserCredentialRepository userCredentialRepository;

//     @Autowired
//     private PasswordEncoder passwordEncoder;

//     @Override
//     public void run(String... args) {
//         // Check if an admin already exists, otherwise create one
//         if (userCredentialRepository.findByUsername("admin").isEmpty()) {
//             System.out.println("⚡ Creating Admin User...");

//             // Create a new admin user and set the email
//             UserCredentialEntity admin = new UserCredentialEntity();
//             admin.setUsername("admin");
//             admin.setPassword(passwordEncoder.encode("admin123"));
//             admin.setRole(Role.ROLE_ADMIN);
//             admin.setEmail("admin@example.com"); // Set the admin's email

//             userCredentialRepository.save(admin);

//             System.out.println("✅ Admin user created successfully.");
//         } else {
//             System.out.println("ℹ️ Admin user already exists.");
//         }
//     }
// }
