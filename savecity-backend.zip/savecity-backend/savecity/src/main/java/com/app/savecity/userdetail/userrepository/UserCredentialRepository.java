package com.app.savecity.userdetail.userrepository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.savecity.userdetail.user.UserCredentialEntity;

public interface UserCredentialRepository extends JpaRepository<UserCredentialEntity, Long> {

    // Correct method declarations that return Optional<UserCredentialEntity>
    Optional<UserCredentialEntity> findByEmail(String email);
    Optional<UserCredentialEntity> findByUsername(String username);

}
