package com.app.savecity;
	
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SavecityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SavecityApplication.class, args);
	}

}
