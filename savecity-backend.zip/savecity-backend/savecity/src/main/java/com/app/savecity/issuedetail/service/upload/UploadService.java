
package com.app.savecity.issuedetail.service.upload;

import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.app.savecity.issuedetail.repository.image.ImageRepository;
import com.app.savecity.issuedetail.entites.issues.Upload;

@Service
public class UploadService {

    @Autowired
    private ImageRepository imageRepository;

    public Upload saveImage(MultipartFile file) throws IOException {
        Upload upload = new Upload();
        upload.setFileName(file.getOriginalFilename());
        upload.setFileType(file.getContentType());
        upload.setFile(file.getBytes());
        return imageRepository.save(upload);
    }

    public Optional<Upload> getImageById(Long id) {
        return imageRepository.findById(id);
    }
}
