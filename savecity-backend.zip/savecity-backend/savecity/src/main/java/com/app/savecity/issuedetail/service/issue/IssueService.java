
package com.app.savecity.issuedetail.service.issue;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.app.savecity.issuedetail.repository.issue.IssueRepository;
import com.app.savecity.issuedetail.service.upload.UploadService;
import com.app.savecity.issuedetail.entites.issues.Issue;
import com.app.savecity.issuedetail.entites.issues.Upload;

@Service
public class IssueService {

    @Autowired
    private IssueRepository issueRepository;

    @Autowired
    private UploadService uploadService;

    public Issue createIssue(String description, List<MultipartFile> files, String location, String issueType) {
        Issue issue = new Issue();
        issue.setDescription(description);
        issue.setLocation(location);
        issue.setIssueType(issueType);

        if (files != null && !files.isEmpty()) {
            StringBuilder uploadIdsBuilder = new StringBuilder();
            for (MultipartFile file : files) {
                try {
                    Upload upload = uploadService.saveImage(file);
                    uploadIdsBuilder.append(upload.getFileId()).append(",");
                } catch (IOException e) {
                    throw new RuntimeException("File upload failed!", e);
                }
            }
            // Remove trailing comma
            issue.setUploadIds(uploadIdsBuilder.toString().replaceAll(",$", ""));
        }
        return issueRepository.save(issue);
    }

    public Optional<com.app.savecity.issuedetail.entites.issues.Issue> getIssueById(Long id) {
        return issueRepository.findById(id);
    }

    public List<com.app.savecity.issuedetail.entites.issues.Issue> getAllIssues() {
        return issueRepository.findAll();
    }

    public boolean deleteIssue(Long id) {
        if (issueRepository.existsById(id)) {
            issueRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
