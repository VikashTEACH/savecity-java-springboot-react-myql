

package com.app.savecity.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.app.savecity.userdetail.user.UserCredentialEntity;

import java.util.Map;

@RestController
@RequestMapping("/savecity/auth")
@CrossOrigin(origins = "http://localhost:5173", allowCredentials = "true")
public class AuthenticationController {

    @Autowired
    private CredentialService credentialService;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(
            @RequestBody Map<String, String> req) {
        try {
            String email = req.get("email");
            String username = req.get("username");
            if (email == null || email.isBlank())
                return ResponseEntity.badRequest()
                    .body("Email cannot be null or empty.");
            if (username == null || username.isBlank())
                return ResponseEntity.badRequest()
                    .body("Username cannot be null or empty.");

            String msg = credentialService.registerUser(req);
            return ResponseEntity.ok(msg);
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @PostMapping("/registerAdmin")
    public ResponseEntity<String> registerAdmin(
            @RequestBody Map<String, String> b) {
        try {
            String msg = credentialService.registerAdmin(
                b.get("username"), b.get("password"), b.get("email"));
            return ResponseEntity.ok(msg);
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @PostMapping("/registerOfficer")
    public ResponseEntity<String> registerOfficer(
            @RequestBody Map<String, String> b) {
        try {
            String msg = credentialService.registerOfficer(
                b.get("username"), b.get("password"), b.get("email"));
            return ResponseEntity.ok(msg);
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String,Object>> login(
            @RequestBody Map<String,String> b) {
        try {
            UserCredentialEntity user =
                credentialService.validateUser(b.get("email"), b.get("password"));
            String token = jwtUtil.generateToken(user.getEmail(), user.getRole());
            return ResponseEntity.ok(Map.of(
                "token", token,
                "role",  user.getRole()
            ));
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("error", ex.getMessage()));
        }
    }
}
